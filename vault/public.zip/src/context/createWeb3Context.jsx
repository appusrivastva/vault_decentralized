import { createContext } from "react";


export const web3Context=createContext()